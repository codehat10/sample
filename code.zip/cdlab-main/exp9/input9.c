main()
{
    int a, b, c;
    if (a == b)
    {
        a = a + b;
    }
    while (a > b)
    {
        a = a - b;
        a = a + 2;
    }
    if (a <= b)
    {
        c = a - b;
        c = c + 2;
    }
    else
    {
        c = a + b;
    }
}
#include <stdio.h>
main()
{
int a, b;
}